﻿namespace Phumla_Kumnandi_Group11_INF2011S.Presentation
{
    partial class ChangeBookingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBookingID = new System.Windows.Forms.Label();
            this.txtBookingID = new System.Windows.Forms.TextBox();
            this.btnSearchBooking = new System.Windows.Forms.Button();
            this.gbBookingDetails = new System.Windows.Forms.GroupBox();
            this.txtLastNameChange = new System.Windows.Forms.TextBox();
            this.lblLastNameChange = new System.Windows.Forms.Label();
            this.txtFirstNameChange = new System.Windows.Forms.TextBox();
            this.lblFirstNameChange = new System.Windows.Forms.Label();
            this.lblCheckInChange = new System.Windows.Forms.Label();
            this.txtGuestNumberChange = new System.Windows.Forms.TextBox();
            this.dateTimePickerCheckInChange = new System.Windows.Forms.DateTimePicker();
            this.lblGuestNumberChange = new System.Windows.Forms.Label();
            this.txtRoomNumbersChange = new System.Windows.Forms.TextBox();
            this.lblCheckOutChange = new System.Windows.Forms.Label();
            this.dateTimePickerCheckOutChange = new System.Windows.Forms.DateTimePicker();
            this.lblRoomNumbersChange = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.gbBookingDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblBookingID
            // 
            this.lblBookingID.AutoSize = true;
            this.lblBookingID.Location = new System.Drawing.Point(52, 53);
            this.lblBookingID.Name = "lblBookingID";
            this.lblBookingID.Size = new System.Drawing.Size(76, 16);
            this.lblBookingID.TabIndex = 0;
            this.lblBookingID.Text = "Booking ID:";
            // 
            // txtBookingID
            // 
            this.txtBookingID.Location = new System.Drawing.Point(209, 47);
            this.txtBookingID.Name = "txtBookingID";
            this.txtBookingID.Size = new System.Drawing.Size(100, 22);
            this.txtBookingID.TabIndex = 1;
            // 
            // btnSearchBooking
            // 
            this.btnSearchBooking.Location = new System.Drawing.Point(410, 41);
            this.btnSearchBooking.Name = "btnSearchBooking";
            this.btnSearchBooking.Size = new System.Drawing.Size(146, 31);
            this.btnSearchBooking.TabIndex = 2;
            this.btnSearchBooking.Text = "Search";
            this.btnSearchBooking.UseVisualStyleBackColor = true;
            this.btnSearchBooking.Click += new System.EventHandler(this.btnSearchBooking_Click);
            // 
            // gbBookingDetails
            // 
            this.gbBookingDetails.BackColor = System.Drawing.Color.Transparent;
            this.gbBookingDetails.Controls.Add(this.txtLastNameChange);
            this.gbBookingDetails.Controls.Add(this.lblLastNameChange);
            this.gbBookingDetails.Controls.Add(this.txtFirstNameChange);
            this.gbBookingDetails.Controls.Add(this.lblFirstNameChange);
            this.gbBookingDetails.Controls.Add(this.lblCheckInChange);
            this.gbBookingDetails.Controls.Add(this.txtGuestNumberChange);
            this.gbBookingDetails.Controls.Add(this.dateTimePickerCheckInChange);
            this.gbBookingDetails.Controls.Add(this.lblGuestNumberChange);
            this.gbBookingDetails.Controls.Add(this.txtRoomNumbersChange);
            this.gbBookingDetails.Controls.Add(this.lblCheckOutChange);
            this.gbBookingDetails.Controls.Add(this.dateTimePickerCheckOutChange);
            this.gbBookingDetails.Controls.Add(this.lblRoomNumbersChange);
            this.gbBookingDetails.Controls.Add(this.btnUpdate);
            this.gbBookingDetails.Location = new System.Drawing.Point(55, 97);
            this.gbBookingDetails.Name = "gbBookingDetails";
            this.gbBookingDetails.Size = new System.Drawing.Size(639, 282);
            this.gbBookingDetails.TabIndex = 3;
            this.gbBookingDetails.TabStop = false;
            this.gbBookingDetails.Text = "BookingDetails";
            // 
            // txtLastNameChange
            // 
            this.txtLastNameChange.Location = new System.Drawing.Point(443, 44);
            this.txtLastNameChange.Name = "txtLastNameChange";
            this.txtLastNameChange.Size = new System.Drawing.Size(100, 22);
            this.txtLastNameChange.TabIndex = 19;
            // 
            // lblLastNameChange
            // 
            this.lblLastNameChange.AutoSize = true;
            this.lblLastNameChange.Location = new System.Drawing.Point(297, 44);
            this.lblLastNameChange.Name = "lblLastNameChange";
            this.lblLastNameChange.Size = new System.Drawing.Size(75, 16);
            this.lblLastNameChange.TabIndex = 18;
            this.lblLastNameChange.Text = "Last Name:";
            // 
            // txtFirstNameChange
            // 
            this.txtFirstNameChange.Location = new System.Drawing.Point(154, 44);
            this.txtFirstNameChange.Name = "txtFirstNameChange";
            this.txtFirstNameChange.Size = new System.Drawing.Size(100, 22);
            this.txtFirstNameChange.TabIndex = 17;
            // 
            // lblFirstNameChange
            // 
            this.lblFirstNameChange.AutoSize = true;
            this.lblFirstNameChange.Location = new System.Drawing.Point(8, 44);
            this.lblFirstNameChange.Name = "lblFirstNameChange";
            this.lblFirstNameChange.Size = new System.Drawing.Size(75, 16);
            this.lblFirstNameChange.TabIndex = 16;
            this.lblFirstNameChange.Text = "First Name:";
            // 
            // lblCheckInChange
            // 
            this.lblCheckInChange.AutoSize = true;
            this.lblCheckInChange.Location = new System.Drawing.Point(8, 95);
            this.lblCheckInChange.Name = "lblCheckInChange";
            this.lblCheckInChange.Size = new System.Drawing.Size(91, 16);
            this.lblCheckInChange.TabIndex = 10;
            this.lblCheckInChange.Text = "Check-in Date";
            // 
            // txtGuestNumberChange
            // 
            this.txtGuestNumberChange.Location = new System.Drawing.Point(466, 197);
            this.txtGuestNumberChange.Name = "txtGuestNumberChange";
            this.txtGuestNumberChange.Size = new System.Drawing.Size(100, 22);
            this.txtGuestNumberChange.TabIndex = 15;
            // 
            // dateTimePickerCheckInChange
            // 
            this.dateTimePickerCheckInChange.Location = new System.Drawing.Point(11, 139);
            this.dateTimePickerCheckInChange.Name = "dateTimePickerCheckInChange";
            this.dateTimePickerCheckInChange.Size = new System.Drawing.Size(243, 22);
            this.dateTimePickerCheckInChange.TabIndex = 8;
            // 
            // lblGuestNumberChange
            // 
            this.lblGuestNumberChange.AutoSize = true;
            this.lblGuestNumberChange.Location = new System.Drawing.Point(297, 203);
            this.lblGuestNumberChange.Name = "lblGuestNumberChange";
            this.lblGuestNumberChange.Size = new System.Drawing.Size(117, 16);
            this.lblGuestNumberChange.TabIndex = 13;
            this.lblGuestNumberChange.Text = "Number of Guests:";
            // 
            // txtRoomNumbersChange
            // 
            this.txtRoomNumbersChange.Location = new System.Drawing.Point(143, 200);
            this.txtRoomNumbersChange.Name = "txtRoomNumbersChange";
            this.txtRoomNumbersChange.Size = new System.Drawing.Size(100, 22);
            this.txtRoomNumbersChange.TabIndex = 14;
            // 
            // lblCheckOutChange
            // 
            this.lblCheckOutChange.AutoSize = true;
            this.lblCheckOutChange.Location = new System.Drawing.Point(297, 95);
            this.lblCheckOutChange.Name = "lblCheckOutChange";
            this.lblCheckOutChange.Size = new System.Drawing.Size(101, 16);
            this.lblCheckOutChange.TabIndex = 11;
            this.lblCheckOutChange.Text = "Check-Out Date";
            // 
            // dateTimePickerCheckOutChange
            // 
            this.dateTimePickerCheckOutChange.Location = new System.Drawing.Point(300, 139);
            this.dateTimePickerCheckOutChange.Name = "dateTimePickerCheckOutChange";
            this.dateTimePickerCheckOutChange.Size = new System.Drawing.Size(243, 22);
            this.dateTimePickerCheckOutChange.TabIndex = 9;
            // 
            // lblRoomNumbersChange
            // 
            this.lblRoomNumbersChange.AutoSize = true;
            this.lblRoomNumbersChange.Location = new System.Drawing.Point(8, 206);
            this.lblRoomNumbersChange.Name = "lblRoomNumbersChange";
            this.lblRoomNumbersChange.Size = new System.Drawing.Size(119, 16);
            this.lblRoomNumbersChange.TabIndex = 12;
            this.lblRoomNumbersChange.Text = "Number of Rooms:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(242, 245);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(146, 31);
            this.btnUpdate.TabIndex = 4;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // ChangeBookingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Phumla_Kumnandi_Group11_INF2011S.Properties.Resources.Formbackground__2_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gbBookingDetails);
            this.Controls.Add(this.btnSearchBooking);
            this.Controls.Add(this.txtBookingID);
            this.Controls.Add(this.lblBookingID);
            this.DoubleBuffered = true;
            this.Name = "ChangeBookingForm";
            this.Text = "ChangeBookingForm";
            this.gbBookingDetails.ResumeLayout(false);
            this.gbBookingDetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBookingID;
        private System.Windows.Forms.TextBox txtBookingID;
        private System.Windows.Forms.Button btnSearchBooking;
        private System.Windows.Forms.GroupBox gbBookingDetails;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label lblCheckInChange;
        private System.Windows.Forms.TextBox txtGuestNumberChange;
        private System.Windows.Forms.DateTimePicker dateTimePickerCheckInChange;
        private System.Windows.Forms.Label lblGuestNumberChange;
        private System.Windows.Forms.TextBox txtRoomNumbersChange;
        private System.Windows.Forms.Label lblCheckOutChange;
        private System.Windows.Forms.DateTimePicker dateTimePickerCheckOutChange;
        private System.Windows.Forms.Label lblRoomNumbersChange;
        private System.Windows.Forms.TextBox txtLastNameChange;
        private System.Windows.Forms.Label lblLastNameChange;
        private System.Windows.Forms.TextBox txtFirstNameChange;
        private System.Windows.Forms.Label lblFirstNameChange;
    }
}